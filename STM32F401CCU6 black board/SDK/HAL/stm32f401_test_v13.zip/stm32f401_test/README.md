# WeAct
## stm32f401_test
WeAct STM32F401 Core Board Test Program
 ![STM32F401CCU6](https://github.com/YXZhu/stm32f401_test/blob/master/stm32.jpg)
