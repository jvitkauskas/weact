/**
  ******************************************************************************
	WeAct ΢�д��� 
	>> ��׼�� TIM
  ******************************************************************************
  */

#ifndef __tim_H
#define __tim_H

#ifdef __cplusplus
 extern "C" {
#endif 

#include "stm32f4xx.h"
#include "main.h"


void TIM_Config(void);

#ifdef __cplusplus
}
#endif

#endif


