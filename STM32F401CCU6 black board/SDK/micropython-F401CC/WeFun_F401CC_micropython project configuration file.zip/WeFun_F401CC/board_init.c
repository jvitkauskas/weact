#include "py/mphal.h"

void WeFun_Core_board_early_init(void) {

}
